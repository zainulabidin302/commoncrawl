from distutils.core import setup
setup(name='cctoathena',
      version='1.0',
      )
